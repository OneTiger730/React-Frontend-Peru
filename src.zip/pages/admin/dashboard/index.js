export const AdminDashboardPage = () => {
    return (
      <div className="container-fluid p-0">
        <div className="card mb-0 d-none d-lg-block">
          <div className="card-body">
            <a href="#0" className="text-dull font">
              TradePro &gt;{" "}
            </a>
            <a href="#0" className="theme-color font-bold font">
              Dashboard
            </a>
          </div>
        </div>
        
        <div className="row mt-4">
          <div className="col-xl-12 col-lg-12 col-12">
            <div className="card mb-0 card-same-height">
              <div className="card-body">
                <div className="row mob-mt-3">
                  <div className="col-xl-12 col-lg-12 col-12">
                    <h1 className="font-24 theme-color font-bold">
                      Admin Dashboard
                    </h1>
                  </div>
                </div>
                <div className="row mt-4">
                    <div className="col-xl-12 col-lg-12 col-12">
                        <div className="alert alert-primary p-4" role="alert">
                            <ul className="alert-ul pl-0 al">
                                <li>
                                <img src="/img/info.svg" alt="" className="img-fluid me-2" />
                                It stash and was even had of collection the latest story still every or times derive come way. Travelling business ill. Helplessly starting didn't should he her bad will so through audiences to the supported congress, if card with was way allows century quarter the control village for of payload.
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div className="row my-4">
                  <div className="col-xl-12 col-lg-12 col-12 my-auto">
                    <p className=" desc  mb-0">Offers it children. Been far good the or so eye. And first the her to white unionized that the absolutely supplies hall to named accuse times had or the to in the monitor a by carefully and than train excessive turned been a rationale to be the little. Agency still a the supported or people out doing place what does one studies of that value designer the you line their transformed extent, you to for not must reflection chequered with got rush than because he with thoughts until sisters term much and bed they of duty organization. And ago. As.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  