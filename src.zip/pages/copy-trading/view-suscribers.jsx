import React from "react";

export const ViewSuscribersPage = () => {
  return <div>wip</div>;
};
