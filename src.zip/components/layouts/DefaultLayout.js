import './../../assets/css/login-styles.scss';

export const DefaultLayout = ({ children }) => {
  return <>{children}</>;
};
